﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RITFacultyV1.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Data;

namespace RITFacultyV1.Services
{
    public class GetCoop
    {
        public async Task<List<CoopInformation>> GetAllCoop()
        {
            //Call the IST RIT API
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://www.ist.rit.edu/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Get and store the API response in 'data' variable, get only the coopInformation list and deserialize to a .NET object
                try
                {
                    HttpResponseMessage response = await client.GetAsync("api/employment/coopTable", HttpCompletionOption.ResponseHeadersRead);
                    response.EnsureSuccessStatusCode();
                    var data = JObject.Parse(await response.Content.ReadAsStringAsync());
                    return data["coopTable"]["coopInformation"].ToObject<List<CoopInformation>>();


                }

                //Catch any errors should the try statement fail
                catch (HttpRequestException hre)
                {
                    var msg = hre.Message;
                    List<CoopInformation> coopList = new List<CoopInformation>();
                    return coopList;
                    //return "HttpRequestException";
                }
                catch (Exception ex)
                {
                    var msg = ex.Message;
                    List<CoopInformation> coopList = new List<CoopInformation>();
                    return coopList;
                    //return "Exception"; ;
                }
            }
        }
    }
}
