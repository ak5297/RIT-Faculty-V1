﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RITFacultyV1.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace RITFacultyV1.Services
{
    public class GetAbout
    {
        public async Task<Dictionary<string, string>> GetAllAbout()
        {
            //Call the IST RIT API
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://www.ist.rit.edu/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Get and store the API response in 'data' variable, deserialize the JSON object into a .NET object
                try
                {
                    HttpResponseMessage response = await client.GetAsync("api/about", HttpCompletionOption.ResponseHeadersRead);
                    response.EnsureSuccessStatusCode();
                    var data = await response.Content.ReadAsStringAsync();

                    var rtnResults = JsonConvert.DeserializeObject<Dictionary<string, string>>(data);

                    return rtnResults;
                }

                //Catch any errors should the try statement fail
                catch (HttpRequestException hre)
                {
                    var msg = hre.Message;
                    Dictionary<string, string> aboutList = new Dictionary<string, string>();
                    return aboutList;
                    //return "HttpRequestException";
                }
                catch (Exception ex)
                {
                    var msg = ex.Message;
                    Dictionary<string, string> aboutList = new Dictionary<string, string>();
                    return aboutList;
                    //return "Exception"; ;
                }
            }
        }
    }
}
