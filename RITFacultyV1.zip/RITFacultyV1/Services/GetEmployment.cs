﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RITFacultyV1.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RITFacultyV1.Services
{
    public class GetEmployment
    {
        public async Task<List<ProfessionalEmploymentInformation>> GetAllEmployment()
        {
            //Call the IST RIT API
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://www.ist.rit.edu/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Get and store the API response in 'data' variable, get only the professionalEmploymentInformation list and deserialize to a .NET object
                try
                {
                    HttpResponseMessage response = await client.GetAsync("api/employment/employmentTable", HttpCompletionOption.ResponseHeadersRead);
                    response.EnsureSuccessStatusCode();
                    var data = JObject.Parse(await response.Content.ReadAsStringAsync());
                    return data["employmentTable"]["professionalEmploymentInformation"].ToObject<List<ProfessionalEmploymentInformation>>();
                }
                catch (HttpRequestException hre)
                {
                    var msg = hre.Message;
                    List<ProfessionalEmploymentInformation> employmentList = new List<ProfessionalEmploymentInformation>();
                    return employmentList;
                    //return "HttpRequestException";
                }

                //Catch any errors should the try statement fail
                catch (Exception ex)
                {
                    var msg = ex.Message;
                    List<ProfessionalEmploymentInformation> employmentList = new List<ProfessionalEmploymentInformation>();
                    return employmentList;
                    //return "Exception"; ;
                }
            }
        }
    }
}
