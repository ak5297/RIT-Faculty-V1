﻿using System;
using System.Collections.Generic;
using RITFacultyV1.Models;

namespace RITFacultyV1.ViewModels
{
    //Convert JSON object to c# methods (for bottom-level objects)
    public class UndergradViewModel
    {
        public List<Undergraduate> Undergraduate { get; set; }
        public string Title { get; set; }

    }
}
