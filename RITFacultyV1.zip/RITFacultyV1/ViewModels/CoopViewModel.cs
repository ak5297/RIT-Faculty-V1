﻿using System.Collections.Generic;
using RITFacultyV1.Models;

namespace RITFacultyV1.ViewModels
{
    //Convert JSON object to c# methods (for bottom-level objects)
    public class CoopTable
    {
        public List<CoopInformation> Coop { get; set; }
        public string Title { get; set; }
    }
}
