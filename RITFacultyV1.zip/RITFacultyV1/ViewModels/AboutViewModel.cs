﻿using System.Collections.Generic;
using RITFacultyV1.Models;

namespace RITFacultyV1.ViewModels
{
    //Convert JSON object to c# methods (for bottom-level objects)
    public class AboutViewModel
    {
        public List<About> About { get; set; }
        public string Title { get; set; }
        public string Header { get; set; }
        public string Description { get; set; }
        public string Quote { get; set; }
        public string QuoteAuthor { get; set; }
    }
}
