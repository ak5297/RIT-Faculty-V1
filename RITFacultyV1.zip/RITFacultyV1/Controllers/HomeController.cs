﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RITFacultyV1.Models;
using RITFacultyV1.ViewModels;
using RITFacultyV1.Services;

namespace RITFacultyV1.Controllers
{
    public class HomeController : Controller
    {

        //Get the about section
        public async Task<IActionResult> About()
        {
            var getallAbout = new GetAbout();
            var allAbout = await getallAbout.GetAllAbout();
            var header = "";
            var description = "";
            var quote = "";
            var quoteAuthor = "";
            allAbout.TryGetValue("title", out header);
            allAbout.TryGetValue("description", out description);
            allAbout.TryGetValue("quote", out quote);
            allAbout.TryGetValue("quoteAuthor", out quoteAuthor);
            var aboutViewModel = new AboutViewModel()
            {
                Title = "About Us",
                Header = header,
                Description = description,
                Quote = quote,
                QuoteAuthor = quoteAuthor

            };
            return View(aboutViewModel);
        }

        //Get the undergraduate section
        public async Task<IActionResult> Under()
        {
            var getallUndergrad = new GetUndergrad();
            var allUndergrad = await getallUndergrad.GetDegrees();
            var sortedUndergrad = allUndergrad.OrderBy(f => f.degreeName);
            var underViewModel = new UndergradViewModel()
            {
                Undergraduate = sortedUndergrad.ToList(),
                Title = "List of Undergraduate Degrees"
            };
            return View(underViewModel);
        }

        //Get the graduate section
        public async Task<IActionResult> Grad()
        {
            var getallGrad = new GetGrad();
            var allGrad = await getallGrad.GetDegrees();
            var sortedGrad = allGrad.OrderBy(f => f.degreeName);
            var gradViewModel = new GradViewModel()
            {
                Graduate = sortedGrad.ToList(),
                Title = "List of Graduate Degrees"
            };
            return View(gradViewModel);
        }

        //Get the minors section
        public async Task<IActionResult> Minors()
        {
            var getallMinors = new GetMinors();
            var allMinors = await getallMinors.GetAllMinors();
            var sortedMinors = allMinors.OrderBy(f => f.name);
            var minorsViewModel = new MinorsViewModel()
            {
                UgMinors = sortedMinors.ToList(),
                Title = "List of Minors"
            };
            return View(minorsViewModel);
        }

        //Get the co-op table
        public async Task<IActionResult> Coop()
        {
            var getallCoop = new GetCoop();
            var allCoop = await getallCoop.GetAllCoop();
            var sortedCoop = allCoop.OrderBy(f => f.employer);
            var coopViewModel = new CoopTable()
            {
                Coop = sortedCoop.ToList(),
                Title = "Co-Op Table"
            };
            return View(coopViewModel);
        }

        //Get the employment table
        public async Task<IActionResult> Employment()
        {
            var getallEmployment = new GetEmployment();
            var allEmployment = await getallEmployment.GetAllEmployment();
            var sortedEmployment = allEmployment.OrderBy(f => f.employer);
            var employmentViewModel = new EmploymentViewModel()
            {
                Employment = sortedEmployment.ToList(),
                Title = "Employment Table"
            };
            return View(employmentViewModel);
        }

        //Get the faculty section
        public async Task<IActionResult> Index()
        {
            var getallFaculty = new GetFaculty();
            var allFaculty = await getallFaculty.GetAllFaculty();
            var sortedFaculty = allFaculty.OrderBy(f => f.username);
            var homeViewModel = new HomeViewModel()
            {
                Faculty = sortedFaculty.ToList(),
                Title = "Our Faculty"
            };
            return View(homeViewModel);
        }
    }
}
