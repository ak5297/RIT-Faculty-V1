using System;

//Convert JSON object to c# methods (for top-level objects)
namespace RITFacultyV1.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}